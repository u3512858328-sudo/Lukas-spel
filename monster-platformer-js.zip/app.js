// Monster Platformer - simple HTML5 Canvas platformer with levels, timer and monsters.
(() => {
  const canvas = document.getElementById('game');
  const ctx = canvas.getContext('2d');
  const W = canvas.width, H = canvas.height;
  const UI = {
    level: document.getElementById('level'),
    time: document.getElementById('time'),
    lives: document.getElementById('lives'),
    message: document.getElementById('message')
  };

  // Controls
  const keys = {};
  window.addEventListener('keydown', e => { keys[e.key.toLowerCase()] = true; if([' ','arrowup','w','a','d','arrowleft','arrowright','r'].includes(e.key.toLowerCase())) e.preventDefault(); });
  window.addEventListener('keyup', e => { keys[e.key.toLowerCase()] = false; });

  // Game constants
  const GRAVITY = 1200; // pixels/s^2
  const JUMP_V = -480;
  const WALK_SPEED = 220;

  // Levels definition: platforms, monsters, timeLimit, bg color or image (simple backgrounds)
  const levels = [
    {
      id:1, timeLimit:30, bg:'#87ceeb', platforms:[ [0,480,900,60], [50,380,140,16], [240,320,120,16], [420,260,120,16], [620,340,180,16] ],
      monsters: [ {type:'ground', x:300, y:464, range:[260,380], speed:60}, {type:'fly', x:520, y:200, pattern:'sine', amp:40, speed:80} ],
      goal:{x:820,y:420,w:40,h:60}
    },
    {
      id:2, timeLimit:28, bg:'#f4e1c1', platforms:[ [0,480,900,60], [90,420,120,16], [260,360,100,16], [380,300,130,16], [560,240,160,16], [740,340,110,16] ],
      monsters: [ {type:'ground', x:200, y:464, range:[160,300], speed:80}, {type:'ground', x:500, y:464, range:[460,620], speed:70}, {type:'fly', x:650, y:180, pattern:'circle', amp:50, speed:100} ],
      goal:{x:820,y:180,w:40,h:60}
    },
    {
      id:3, timeLimit:25, bg:'#d0f0c0', platforms:[ [0,480,900,60], [30,420,110,16], [180,360,110,16], [340,300,130,16], [520,250,120,16], [700,200,120,16] ],
      monsters: [ {type:'ground', x:150, y:464, range:[110,240], speed:90}, {type:'ground', x:400, y:464, range:[360,480], speed:85}, {type:'fly', x:580, y:150, pattern:'sine', amp:60, speed:110}, {type:'fly', x:720, y:120, pattern:'circle', amp:40, speed:130} ],
      goal:{x:820,y:140,w:40,h:60}
    }
  ];

  // Entities
  class Player {
    constructor(x,y){ this.x=x; this.y=y; this.w=36; this.h=48; this.vx=0; this.vy=0; this.onGround=false; this.lives=3; }
    reset(x,y){ this.x=x; this.y=y; this.vx=0; this.vy=0; this.onGround=false; }
    update(dt, level){ // input
      if(keys['a']||keys['arrowleft']) this.vx = -WALK_SPEED;
      else if(keys['d']||keys['arrowright']) this.vx = WALK_SPEED;
      else this.vx = 0;
      if((keys['w']||keys[' ']||keys['arrowup']) && this.onGround){ this.vy = JUMP_V; this.onGround=false; }
      // physics
      this.vy += GRAVITY*dt;
      this.x += this.vx*dt;
      this.y += this.vy*dt;
      // collisions with platforms
      this.onGround = false;
      for(const p of level.platforms){
        if(rectIntersect(this.x,this.y,this.w,this.h, p[0],p[1],p[2],p[3])){
          // simple resolution - only support landing on top
          if(this.vy > 0 && (this.y + this.h - this.vy*dt) <= p[1]){
            this.y = p[1] - this.h; this.vy = 0; this.onGround = true;
          }
        }
      }
      // bounds
      if(this.x < 0) this.x = 0;
      if(this.x + this.w > W) this.x = W - this.w;
      if(this.y > H){ this.lives--; return 'dead'; }
    }
    draw(ctx){ ctx.fillStyle='#222'; ctx.fillRect(this.x,this.y,this.w,this.h); ctx.fillStyle='#fff'; ctx.fillRect(this.x+6,this.y+8, this.w-12, this.h-12); }
  }

  class Monster {
    constructor(spec){
      this.type = spec.type;
      this.x = spec.x; this.y = spec.y;
      this.w = (this.type==='fly')?36:34; this.h = (this.type==='fly')?28:30;
      this.spec = spec; this.dir = 1; this.t = 0;
    }
    update(dt){
      this.t += dt;
      if(this.type === 'ground'){
        const [a,b] = this.spec.range; this.x += this.spec.speed * this.dir * dt;
        if(this.x < a) { this.x = a; this.dir = 1; }
        if(this.x > b) { this.x = b; this.dir = -1; }
      } else if(this.type === 'fly'){
        if(this.spec.pattern === 'sine'){
          this.x += this.spec.speed * dt * 0.6;
          this.y = this.spec.y + Math.sin(this.t * this.spec.speed * 0.02) * this.spec.amp;
        } else if(this.spec.pattern === 'circle'){
          this.x = this.spec.x + Math.cos(this.t * this.spec.speed * 0.01) * this.spec.amp;
          this.y = this.spec.y + Math.sin(this.t * this.spec.speed * 0.01) * this.spec.amp;
        }
      }
    }
    draw(ctx){ ctx.fillStyle=(this.type==='fly')?'#a22':'#841'; ctx.fillRect(this.x, this.y, this.w, this.h); ctx.fillStyle='#000'; ctx.fillRect(this.x+4,this.y+4, this.w-8, this.h-8); }
  }

  // Utilities
  function rectIntersect(x,y,w,h, rx,ry,rw,rh){ return !(x+w < rx || x > rx+rw || y+h < ry || y > ry+rh); }

  // Game controller
  let currentLevelIndex = 0;
  let player = new Player(40, 420);
  let monsters = [];
  let levelStartTime = 0;
  let remaining = 0;
  let running = false;

  function loadLevel(i){
    const lvl = levels[i];
    // create monsters
    monsters = lvl.monsters.map(s => new Monster(s));
    player.reset(40, 420);
    UI.level.textContent = lvl.id;
    remaining = lvl.timeLimit;
    levelStartTime = performance.now();
    UI.time.textContent = Math.ceil(remaining);
    UI.lives.textContent = player.lives;
    running = true;
    UI.message.classList.add('hidden');
  }

  function nextLevel(){
    currentLevelIndex = (currentLevelIndex + 1) % levels.length;
    loadLevel(currentLevelIndex);
  }

  loadLevel(0);

  // Main loop
  let last = performance.now();
  function loop(now){
    const dt = Math.min(0.05, (now-last)/1000);
    last = now;
    if(running){
      const lvl = levels[currentLevelIndex];
      // timer
      remaining -= dt;
      if(remaining <= 0){
        running = false; UI.message.textContent = 'Tiden är slut! Tryck R för att försök igen.'; UI.message.classList.remove('hidden');
      }
      // update player
      const res = player.update(dt, lvl);
      if(res === 'dead'){
        running = false; UI.message.textContent = 'Du föll! Tryck R för att starta om nivån.'; UI.message.classList.remove('hidden');
      }
      // update monsters
      monsters.forEach(m=>m.update(dt));
      // collisions player-monster
      for(const m of monsters){
        if(rectIntersect(player.x, player.y, player.w, player.h, m.x, m.y, m.w, m.h)){
          // simple: lose a life & reset position
          player.lives--; UI.lives.textContent = player.lives;
          if(player.lives <= 0){ running = false; UI.message.textContent = 'Spelet över! Tryck R för att börja om.'; UI.message.classList.remove('hidden'); break; }
          else { player.reset(40,420); break; }
        }
      }
      // check goal
      if(rectIntersect(player.x, player.y, player.w, player.h, lvl.goal.x, lvl.goal.y, lvl.goal.w, lvl.goal.h)){
        running = false; UI.message.textContent = 'Nivå klar! Tryck R för nästa nivå.'; UI.message.classList.remove('hidden');
        // advance level on R press (handled below)
      }
      UI.time.textContent = Math.ceil(Math.max(0, remaining));
    }

    // input for restart/next
    if(keys['r'] && !running){
      // if player has lives, and message was level clear advance; otherwise reload same level or reset
      const msg = UI.message.textContent;
      if(msg.includes('Nivå klar')) nextLevel();
      else if(msg.includes('Spelet över')) {
        player.lives = 3; currentLevelIndex = 0; loadLevel(0);
      } else {
        loadLevel(currentLevelIndex);
      }
    }

    // render
    render();
    requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);

  function render(){
    const lvl = levels[currentLevelIndex];
    // background
    ctx.fillStyle = lvl.bg; ctx.fillRect(0,0,W,H);
    // platforms
    ctx.fillStyle = '#654321';
    for(const p of lvl.platforms) ctx.fillRect(p[0], p[1], p[2], p[3]);
    // goal
    ctx.fillStyle = '#ff0'; const g = lvl.goal; ctx.fillRect(g.x, g.y, g.w, g.h);
    // monsters
    monsters.forEach(m=>m.draw(ctx));
    // player
    player.draw(ctx);
    // HUD debug (optional)
  }

})();
