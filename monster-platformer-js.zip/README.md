# Monster Platformer — JavaScript (Web) (GitHub-ready)

Enkel 2D-plattformsspel byggt med HTML5 Canvas.
Spelaren hoppar på plattformar, undviker monster och ska nå måltavlan inom en tidsgräns.
Varje genomfört nivå laddar en ny bana och nya monster. Projektet är redo att pushas till GitHub.

## Funktioner
- Flera nivåer (bakgrunder och layouts byts automatiskt när du klarar en nivå).
- Olika monster: markmonstrar (patrullerar) och flygande monster (rör sig i mönster).
- Tidsbegränsning per nivå — om tiden tar slut förlorar spelaren och kan starta om nivån.
- Måltavla (flagga) i slutet av varje bana.
- Enkelt API för att lägga till fler nivåer eller monstertyper.

## Katalogstruktur
- index.html — startsida och canvas
- style.css — enkel styling
- app.js — spelmotor (rendering, uppdatering, nivåer, monster, timer)
- assets/ — plats för bakgrundsbilder och ljud (valfritt)
- README.md, LICENSE, .gitignore

## Kom igång lokalt
1. Packa upp eller klona repot.
2. Öppna `index.html` i din webbläsare eller kör en enkel lokal server, t.ex. `python -m http.server 8000` i projektmappen.

## Publicera på GitHub
1. Initiera lokalt git och gör commit:
   ```bash
   git init
   git add .
   git commit -m "Initial commit - monster platformer"
   git branch -M main
   git remote add origin git@github.com:<user>/<repo>.git
   git push -u origin main
   ```
2. Aktivera GitHub Pages (valfritt) för att spela direkt i webbläsaren.

## Licens
MIT
